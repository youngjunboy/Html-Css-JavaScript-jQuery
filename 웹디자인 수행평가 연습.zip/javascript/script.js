jQuery(document).ready(function(){

    $

});